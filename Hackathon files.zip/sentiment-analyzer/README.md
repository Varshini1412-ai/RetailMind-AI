# Sentiment & Emotion Analyzer

A lightweight web app that analyzes the **sentiment** (positive/negative) and
**emotion** (joy, anger, sadness, fear, surprise, disgust, neutral) of text —
paste reviews, tweets, or feedback and get instant results with charts.

Built for a hackathon: fast to set up, uses pre-trained NLP models (no
training required), and stores every analysis for a history dashboard.

## Stack

- **Backend:** Flask
- **NLP:** Hugging Face Transformers (`distilbert-base-uncased-finetuned-sst-2-english`
  for sentiment, `j-hartmann/emotion-english-distilroberta-base` for emotion)
- **Database:** SQLite (via built-in `sqlite3`)
- **Charts:** Plotly.js
- **Frontend:** Vanilla HTML/CSS/JavaScript

## Features

- Paste multiple lines of text and get batch sentiment + emotion analysis
- Interactive charts (pie for sentiment, bar for emotion) per-request and all-time
- Every analysis is saved to SQLite, viewable on the History page
- Clean dark-mode UI, no frontend framework/build step needed

## Setup

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/sentiment-analyzer.git
cd sentiment-analyzer

# 2. Create a virtual environment
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
python app.py
```

Then open **http://localhost:5000** in your browser.

> Note: the first run will download the two Hugging Face models
> (~500MB total) — this can take a few minutes depending on your connection.

## Project structure

```
sentiment-analyzer/
├── app.py                  # Flask routes
├── models/
│   └── analyzer.py         # Hugging Face sentiment + emotion pipelines
├── database/
│   └── db.py                # SQLite helper functions
├── templates/
│   ├── base.html
│   ├── index.html           # Analyze page
│   └── history.html         # History/dashboard page
├── static/
│   ├── css/style.css
│   └── js/
│       ├── main.js          # Analyze page logic + Plotly charts
│       └── history.js       # History page logic + Plotly charts
├── data/                    # SQLite DB lives here (gitignored)
├── requirements.txt
└── README.md
```

## API

### `POST /analyze`
Request body:
```json
{ "text": "I loved this product!\nThe support team was unhelpful." }
```
Response:
```json
{
  "count": 2,
  "results": [
    {
      "text": "I loved this product!",
      "sentiment": { "label": "POSITIVE", "score": 0.9998 },
      "emotion": { "label": "joy", "score": 0.95 },
      "emotion_distribution": [ { "label": "joy", "score": 0.95 }, ... ]
    }
  ]
}
```

### `GET /api/history`
Returns all stored analyses plus aggregate counts for charts.

## Possible extensions

- CSV upload for bulk analysis of existing datasets
- Auth so each user only sees their own history
- Swap SQLite for Postgres for production deployment
- Add a confidence threshold / "neutral" bucket for sentiment

## License

MIT — free to use and modify for your hackathon submission.
